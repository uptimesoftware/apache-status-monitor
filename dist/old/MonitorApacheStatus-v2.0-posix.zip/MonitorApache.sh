#!/bin/sh

..\..\apache\php\php MonitorApache.php

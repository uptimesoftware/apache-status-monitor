/usr/bin/php -q MonitorApache.php $*

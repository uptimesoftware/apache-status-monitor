<?php

/*
Author: Kenneth Cheung
Date: 06.26.2008
Description: This is a plug-in monitor that interacts with MOD-STATUS through the machine readable 
	interface on Apache Servers. ModStatus must be enabled, and for the stats to be complete the directive 
	extendedstatus should be set to on in apache.conf, as well in the directive the domain of the monitoring station should
	be allowed to query the URL
Usage: Install appropriate files in scripts and xml folder then use erdcloader to load this into the core
Notes: Needs to be configured per SERVER!
*/

//** TEST CODE REMOVE/COMMENT FOR DELIVERY ****
//echo "args ".$argv[1]." ".$argv[2];


//grab the second argument from up.time which should be the URL to the mod status handler on a given webserver
$statusURL = $argv[2];

//** TEST CODE REMOVE/COMMENT FOR DELIVERY ****
//$statusURL = "http://www.nethium.net/server-status?auto";

$status_output = file_get_contents( $statusURL );

//** TEST CODE REMOVE/COMMENT FOR DELIVERY ****		
//echo $status_output;	

//if we got something from the call then we need to clean it up for up.time

	if($status_output){ //only if this got set by our call
	
		//clean out the spaces
		$status_output = ereg_replace(' ', '', $status_output);
		//convert the semicolons to spaces now (yes this makes sense even though you may not get it at first glance)
		//$status_output = preg_replace(':', '1 ', $status_ouput);
	
		//since preg/ereg/str_replace don't work on semicolons for some unknown reason
		$arrayOutput=split(':',$status_output);
		
	
		//output = sizeof($arrayOutput);
		//iterate through and rebuild this thing no need to strip out the scoreboard uptime won't pick it up because it won't be part of the definition
		for ($iCounter=0;$iCounter<10;$iCounter++){		
			$ut_status_output=trim($ut_status_output)." ".$arrayOutput[$iCounter];
		}
		
		//output to std_out for uptime		
		echo $ut_status_output;	
	
	}else {
		
		echo "ERROR: Monitor could not connect to MOD-STATUS on your apache server. The passed in URL was".$argv[2]."Please ensure that you have mod-status enabled, the extended status directive enabled, and have given the monitoring station domain permissions to call the directive.";
	}


?>


